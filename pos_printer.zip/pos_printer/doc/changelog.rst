.. _changelog:

Changelog
=========



`Version 0.1.5 (Sat, 05 Jun 2021 23:44:27 +0300)
------------------------------------------------------
- [IMP] Center the image before printing. 

`Version 0.1.4 (Wed, 10 Mar 2021 04:11:12 +0300)
------------------------------------------------------
- [IMP] For long receipts over 255 pixels in height, it is better to slice them into small images before sending to the printer for buffering reasons

`Version 0.1.3 (Tue, 09 Mar 2021 03:16:34 +0300)
------------------------------------------------------
- [IMP] removed try statement in import line

`Version 0.1.2 (Tue, 09 Mar 2021 02:36:02 +0300)
------------------------------------------------------
- [IMP] Further changes to import lines to fix Odoo.sh issue related to importation.

`Version 0.1.1 (Tue, 09 Mar 2021 01:15:20 +0300)
------------------------------------------------------
- [IMP] changed how to import escpos modules to be compatible with ODOO.SH

`Version 0.1.0 (Thu Nov  5 03:41:35 2020)`
--------------------------------------------
- Initial Release for Odoo 14.0

