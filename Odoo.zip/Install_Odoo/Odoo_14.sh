#!/bin/bash

# Mise à jour “apt“
#apt update
#apt upgrade -y

# Installation de “PostGreSQL“
apt install postgresql -y

# Installation de “Odoo“
wget -O - https://nightly.odoo.com/odoo.key | apt-key add -
echo "deb http://nightly.odoo.com/14.0/nightly/deb/ ./" >> /etc/apt/sources.list.d/odoo.list
apt-get update && apt-get install odoo -y

# Mise à jour “apt“
#apt update
#apt upgrade -y

# Installation de “wkthmltopdf“
apt install wkhtmltopdf -y

# Installation de “pip3“
apt install python3-pip -y

# Installation de “reportlab“ & “num2words“
pip3 install reportlab --upgrade
pip3 install num2words --upgrade

# Installation des Modules Odoo
# Module “product_barcode“
# Cybrosys
# Génération de code-barre pour les nouveaux produits
cp -R /home/ali/Install_Odoo/Modules/product_barcode /usr/lib/python3/dist-packages/odoo/addons/
#chown -R odoo: /usr/lib/python3/dist-packages/odoo/addons/product_barcode
#chmod -R 755 /usr/lib/python3/dist-packages/odoo/addons/product_barcode
# Autre module
#...

# Mise à jour “apt“
#apt update
#apt upgrade -y
#apt autoremove -y

# Installation de la modification de PoS
# Intégration d'un champs de saisie de code-barre dans le PdV
cp /home/ali/Install_Odoo/Barcode_PoS/Chrome.js /usr/lib/python3/dist-packages/odoo/addons/point_of_sale/static/src/js/Chrome.js
cp /home/ali/Install_Odoo/Barcode_PoS/Chrome.xml /usr/lib/python3/dist-packages/odoo/addons/point_of_sale/static/src/xml
cp /home/ali/Install_Odoo/Barcode_PoS/DebugWidget.js /usr/lib/python3/dist-packages/odoo/addons/point_of_sale/static/src/js/ChromeWidgets
cp /home/ali/Install_Odoo/Barcode_PoS/DebugWidget.xml /usr/lib/python3/dist-packages/odoo/addons/point_of_sale/static/src/xml/ChromeWidgets
cp /home/ali/Install_Odoo/Barcode_PoS/pos.css /usr/lib/python3/dist-packages/odoo/addons/point_of_sale/static/src/css

# Donner les droits d'accés à l'utilisateur “ali“
chown -R root: /usr/lib/python3/dist-packages/odoo

# Reboot de la machine
#echo “Appuyer sur une touche pour redémarrer la machine...“
#read
#reboot